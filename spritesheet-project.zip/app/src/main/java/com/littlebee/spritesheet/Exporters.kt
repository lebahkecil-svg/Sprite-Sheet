package com.littlebee.spritesheet

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.BufferedOutputStream
import java.io.File
import java.io.OutputStream
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/* ---------- Sumber frame ---------- */

interface FrameSource {
    val count: Int
    val natW: Int
    val natH: Int
    fun frame(i: Int, w: Int, h: Int, bg: Int?): Bitmap
}

class GeneratedSource(val rig: Rig, val motion: Motion) : FrameSource {
    override val count: Int get() = motion.frameCount
    override val natW: Int get() = SheetBuilder.CW
    override val natH: Int get() = SheetBuilder.CH
    override fun frame(i: Int, w: Int, h: Int, bg: Int?): Bitmap =
        rig.render(motion.gen(i, rig.saluteDeg), w, h, bg)
}

class SheetSource(val sheet: Bitmap, val cols: Int, val rows: Int) : FrameSource {
    private val paint = Paint().apply { isFilterBitmap = true }
    private val cw = sheet.width / cols
    private val ch = sheet.height / rows
    override val count: Int get() = cols * rows
    override val natW: Int get() = cw
    override val natH: Int get() = ch
    override fun frame(i: Int, w: Int, h: Int, bg: Int?): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        if (bg != null) c.drawColor(bg)
        val col = i % cols
        val row = i / cols
        val src = Rect(col * cw, row * ch, col * cw + cw, row * ch + ch)
        val s = min(w.toFloat() / cw, h.toFloat() / ch)
        val dw = cw * s
        val dh = ch * s
        val dst = RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f)
        c.drawBitmap(sheet, src, dst, paint)
        return out
    }
}

fun fitSize(natW: Int, natH: Int, maxSide: Int, mult: Int): Pair<Int, Int> {
    val s = min(1f, maxSide.toFloat() / max(natW, natH))
    val w = max(mult, ceil(natW * s / mult).toInt() * mult)
    val h = max(mult, ceil(natH * s / mult).toInt() * mult)
    return Pair(w, h)
}

/* ---------- Sprite sheet PNG ---------- */

object SheetBuilder {
    const val CW = 256
    const val CH = 320

    fun cols(n: Int): Int = if (n <= 20) 5 else 10

    fun build(src: GeneratedSource): Bitmap {
        val n = src.count
        val cols = cols(n)
        val rows = (n + cols - 1) / cols
        val sheet = Bitmap.createBitmap(cols * CW, rows * CH, Bitmap.Config.ARGB_8888)
        val c = Canvas(sheet)
        for (i in 0 until n) {
            val f = src.frame(i, CW, CH, null)
            c.drawBitmap(f, ((i % cols) * CW).toFloat(), ((i / cols) * CH).toFloat(), null)
            f.recycle()
        }
        return sheet
    }
}

/* ---------- GIF ---------- */

object Quantizer {
    fun palette(frames: List<IntArray>): IntArray {
        var total = 0L
        for (f in frames) total += f.size
        val stride = max(1L, total / 40000L).toInt()
        val sample = ArrayList<Int>()
        for (f in frames) {
            var i = 0
            while (i < f.size) {
                sample.add(f[i] and 0xFFFFFF)
                i += stride
            }
        }
        val boxes = ArrayList<IntArray>()
        boxes.add(sample.toIntArray())
        while (boxes.size < 256) {
            var best = -1
            var bestSize = 1
            var bestCh = 0
            for (k in boxes.indices) {
                val bx = boxes[k]
                if (bx.size <= bestSize) continue
                var rmin = 255
                var rmax = 0
                var gmin = 255
                var gmax = 0
                var bmin = 255
                var bmax = 0
                for (c in bx) {
                    val r = (c shr 16) and 255
                    val g = (c shr 8) and 255
                    val b = c and 255
                    if (r < rmin) rmin = r
                    if (r > rmax) rmax = r
                    if (g < gmin) gmin = g
                    if (g > gmax) gmax = g
                    if (b < bmin) bmin = b
                    if (b > bmax) bmax = b
                }
                val rr = rmax - rmin
                val gr = gmax - gmin
                val br = bmax - bmin
                val mx = max(rr, max(gr, br))
                if (mx > 0) {
                    best = k
                    bestSize = bx.size
                    bestCh = if (mx == rr) 0 else if (mx == gr) 1 else 2
                }
            }
            if (best < 0) break
            val bx = boxes.removeAt(best)
            val shift = when (bestCh) {
                0 -> 16
                1 -> 8
                else -> 0
            }
            val sorted = bx.sortedBy { (it shr shift) and 255 }
            val mid = sorted.size / 2
            boxes.add(sorted.subList(0, mid).toIntArray())
            boxes.add(sorted.subList(mid, sorted.size).toIntArray())
        }
        val pal = IntArray(256)
        for (k in boxes.indices) {
            val bx = boxes[k]
            var r = 0L
            var g = 0L
            var b = 0L
            for (c in bx) {
                r += (c shr 16) and 255
                g += (c shr 8) and 255
                b += c and 255
            }
            val n = max(1, bx.size)
            pal[k] = ((r / n).toInt() shl 16) or ((g / n).toInt() shl 8) or (b / n).toInt()
        }
        return pal
    }

    fun lut(pal: IntArray): ByteArray {
        val t = ByteArray(32768)
        for (key in 0 until 32768) {
            val r = ((key shr 10) shl 3) or 4
            val g = (((key shr 5) and 31) shl 3) or 4
            val b = ((key and 31) shl 3) or 4
            var best = 0
            var bd = Int.MAX_VALUE
            for (k in 0 until 256) {
                val pc = pal[k]
                val dr = r - ((pc shr 16) and 255)
                val dg = g - ((pc shr 8) and 255)
                val db = b - (pc and 255)
                val d = dr * dr + dg * dg + db * db
                if (d < bd) {
                    bd = d
                    best = k
                }
            }
            t[key] = best.toByte()
        }
        return t
    }
}

private class SubBlockWriter(private val out: OutputStream) {
    private val buf = ByteArray(255)
    private var n = 0
    private var acc = 0
    private var bits = 0

    fun put(code: Int, size: Int) {
        acc = acc or (code shl bits)
        bits += size
        while (bits >= 8) {
            add(acc and 255)
            acc = acc ushr 8
            bits -= 8
        }
    }

    private fun add(b: Int) {
        buf[n++] = b.toByte()
        if (n == 255) flushBlock()
    }

    private fun flushBlock() {
        if (n > 0) {
            out.write(n)
            out.write(buf, 0, n)
            n = 0
        }
    }

    fun finish() {
        if (bits > 0) {
            add(acc and 255)
            acc = 0
            bits = 0
        }
        flushBlock()
    }
}

class GifWriter(
    private val out: OutputStream,
    private val w: Int,
    private val h: Int,
    palette: IntArray,
    private val delayCs: Int
) {
    init {
        out.write("GIF89a".toByteArray())
        writeShort(w)
        writeShort(h)
        out.write(0xF7)
        out.write(0)
        out.write(0)
        for (c in palette) {
            out.write((c shr 16) and 255)
            out.write((c shr 8) and 255)
            out.write(c and 255)
        }
        out.write(0x21)
        out.write(0xFF)
        out.write(0x0B)
        out.write("NETSCAPE2.0".toByteArray())
        out.write(0x03)
        out.write(0x01)
        writeShort(0)
        out.write(0)
    }

    private fun writeShort(v: Int) {
        out.write(v and 255)
        out.write((v shr 8) and 255)
    }

    fun frame(idx: ByteArray) {
        out.write(0x21)
        out.write(0xF9)
        out.write(0x04)
        out.write(0x00)
        writeShort(delayCs)
        out.write(0)
        out.write(0)
        out.write(0x2C)
        writeShort(0)
        writeShort(0)
        writeShort(w)
        writeShort(h)
        out.write(0)
        lzw(idx)
    }

    private fun lzw(pix: ByteArray) {
        val minCode = 8
        out.write(minCode)
        val clear = 1 shl minCode
        val eoi = clear + 1
        var codeSize = minCode + 1
        var next = eoi + 1
        val dict = HashMap<Int, Int>()
        val bw = SubBlockWriter(out)
        bw.put(clear, codeSize)
        var prefix = pix[0].toInt() and 0xFF
        for (i in 1 until pix.size) {
            val c = pix[i].toInt() and 0xFF
            val key = (prefix shl 8) or c
            val found = dict[key]
            if (found != null) {
                prefix = found
            } else {
                bw.put(prefix, codeSize)
                if (next > (1 shl codeSize) - 1 && codeSize < 12) codeSize++
                if (next < 4096) {
                    dict[key] = next
                    next++
                } else {
                    bw.put(clear, codeSize)
                    dict.clear()
                    next = eoi + 1
                    codeSize = minCode + 1
                }
                prefix = c
            }
        }
        bw.put(prefix, codeSize)
        if (next > (1 shl codeSize) - 1 && codeSize < 12) codeSize++
        bw.put(eoi, codeSize)
        bw.finish()
        out.write(0)
    }

    fun finish() {
        out.write(0x3B)
        out.flush()
    }
}

object GifExporter {
    fun export(src: FrameSource, w: Int, h: Int, fps: Int, bg: Int, os: OutputStream, progress: (String) -> Unit) {
        val pix = ArrayList<IntArray>()
        for (i in 0 until src.count) {
            val b = src.frame(i, w, h, bg)
            val a = IntArray(w * h)
            b.getPixels(a, 0, w, 0, 0, w, h)
            b.recycle()
            pix.add(a)
            progress("Menyiapkan frame ${i + 1}/${src.count}")
        }
        progress("Membuat palet warna…")
        val pal = Quantizer.palette(pix)
        val lut = Quantizer.lut(pal)
        val bos = BufferedOutputStream(os, 1 shl 16)
        val gw = GifWriter(bos, w, h, pal, max(2, (100f / fps).roundToInt()))
        val idx = ByteArray(w * h)
        for (k in pix.indices) {
            val a = pix[k]
            for (p in a.indices) {
                val c = a[p]
                val key = (((c shr 19) and 31) shl 10) or (((c shr 11) and 31) shl 5) or ((c shr 3) and 31)
                idx[p] = lut[key]
            }
            gw.frame(idx)
            progress("Menulis GIF ${k + 1}/${pix.size}")
        }
        gw.finish()
    }
}

/* ---------- MP4 ---------- */

object Mp4Exporter {
    fun export(src: FrameSource, w: Int, h: Int, fps: Int, bg: Int, outFile: File, progress: (String) -> Unit) {
        val loops = max(1, ceil(3.0 * fps / src.count).toInt())
        val total = src.count * loops

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
        format.setInteger(MediaFormat.KEY_BIT_RATE, 4_000_000)
        format.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)

        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var muxStarted = false
        val info = MediaCodec.BufferInfo()
        var inIdx = 0
        var inputDone = false
        var outputDone = false
        val frameUs = 1_000_000L / fps
        try {
            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        if (inIdx >= total) {
                            codec.queueInputBuffer(ii, 0, 0, inIdx * frameUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val img = codec.getInputImage(ii)
                                ?: throw IllegalStateException("Encoder HP ini tidak mendukung input gambar")
                            val bmp = src.frame(inIdx % src.count, w, h, bg)
                            fillImage(img, bmp, w, h)
                            bmp.recycle()
                            codec.queueInputBuffer(ii, 0, w * h * 3 / 2, inIdx * frameUs, 0)
                            inIdx++
                            progress("Encode MP4 $inIdx/$total")
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(codec.outputFormat)
                    muxer.start()
                    muxStarted = true
                } else if (oi >= 0) {
                    val buf = codec.getOutputBuffer(oi)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && muxStarted && buf != null) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        muxer.writeSampleData(track, buf, info)
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                }
            }
        } finally {
            try {
                codec.stop()
            } catch (e: Exception) {
            }
            codec.release()
            try {
                if (muxStarted) muxer.stop()
            } catch (e: Exception) {
            }
            muxer.release()
        }
    }

    private fun clamp(v: Int): Byte = (if (v < 0) 0 else if (v > 255) 255 else v).toByte()

    private fun fillImage(img: Image, bmp: Bitmap, w: Int, h: Int) {
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val planes = img.planes
        val yP = planes[0]
        val uP = planes[1]
        val vP = planes[2]
        val yB = yP.buffer
        val uB = uP.buffer
        val vB = vP.buffer
        for (j in 0 until h) {
            for (i in 0 until w) {
                val c = px[j * w + i]
                val r = (c shr 16) and 255
                val g = (c shr 8) and 255
                val b = c and 255
                yB.put(j * yP.rowStride + i * yP.pixelStride, clamp(((66 * r + 129 * g + 25 * b + 128) shr 8) + 16))
                if ((j and 1) == 0 && (i and 1) == 0) {
                    val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                    val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                    uB.put((j / 2) * uP.rowStride + (i / 2) * uP.pixelStride, clamp(u))
                    vB.put((j / 2) * vP.rowStride + (i / 2) * vP.pixelStride, clamp(v))
                }
            }
        }
    }
}
