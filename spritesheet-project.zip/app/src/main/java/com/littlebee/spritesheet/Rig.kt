package com.littlebee.spritesheet

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class RigParams(
    var neck: Float = 0.38f,
    var hip: Float = 0.68f,
    var arm: Float = 0.28f,
    var tol: Int = 40,
    var faceLeft: Boolean = false
)

object Segmenter {
    /** Membuang latar polos: flood-fill dari tepi gambar. Piksel tokoh tidak diubah sama sekali. */
    fun removeBackground(src: Bitmap, tol: Int): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        var r = 0L
        var g = 0L
        var b = 0L
        var n = 0
        if (w >= 8 && h >= 8) {
            val corners = listOf(Pair(0, 0), Pair(w - 4, 0), Pair(0, h - 4), Pair(w - 4, h - 4))
            for (cn in corners) {
                for (y in cn.second until cn.second + 4) {
                    for (x in cn.first until cn.first + 4) {
                        val c = px[y * w + x]
                        if ((c ushr 24) >= 16) {
                            r += (c shr 16) and 255
                            g += (c shr 8) and 255
                            b += c and 255
                            n++
                        }
                    }
                }
            }
        }
        val br = if (n > 0) (r / n).toInt() else 255
        val bg = if (n > 0) (g / n).toInt() else 255
        val bb = if (n > 0) (b / n).toInt() else 255
        val limit = tol * 3

        fun isBg(c: Int): Boolean {
            if ((c ushr 24) < 16) return true
            val d = abs(((c shr 16) and 255) - br) + abs(((c shr 8) and 255) - bg) + abs((c and 255) - bb)
            return d <= limit
        }

        val seen = BooleanArray(w * h)
        val queue = IntArray(w * h)
        var head = 0
        var tail = 0
        fun push(x: Int, y: Int) {
            val i = y * w + x
            if (!seen[i] && isBg(px[i])) {
                seen[i] = true
                queue[tail++] = i
            }
        }
        for (x in 0 until w) {
            push(x, 0)
            push(x, h - 1)
        }
        for (y in 0 until h) {
            push(0, y)
            push(w - 1, y)
        }
        while (head < tail) {
            val i = queue[head++]
            val x = i % w
            val y = i / w
            if (x > 0) push(x - 1, y)
            if (x < w - 1) push(x + 1, y)
            if (y > 0) push(x, y - 1)
            if (y < h - 1) push(x, y + 1)
        }
        val out = IntArray(w * h)
        for (i in out.indices) {
            out[i] = if (seen[i]) 0 else (px[i] or (0xFF shl 24))
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }
}

/**
 * Rig boneka 2D: foto dipotong jadi kepala, badan, 2 lengan, 2 kaki (piksel asli dari foto),
 * lalu digerakkan dengan rotasi di sendi. Tidak ada piksel baru yang digambar AI.
 */
class Rig(seg: Bitmap, p: RigParams) {
    var bw = 0
        private set
    var bh = 0
        private set
    var saluteDeg = 40f
        private set

    private val paint = Paint().apply {
        isFilterBitmap = true
        isAntiAlias = true
    }

    private lateinit var head: Bitmap
    private lateinit var torso: Bitmap
    private lateinit var armLb: Bitmap
    private lateinit var armRb: Bitmap
    private lateinit var legLb: Bitmap
    private lateinit var legRb: Bitmap

    private var neckY = 0f
    private var hipY = 0f
    private var armW = 0f
    private var armRx = 0f
    private var legRx = 0f
    private var armPy = 0f
    private var legLpx = 0f
    private var legRpx = 0f

    init {
        val w = seg.width
        val h = seg.height
        val px = IntArray(w * h)
        seg.getPixels(px, 0, w, 0, 0, w, h)
        var x0 = w
        var y0 = h
        var x1 = -1
        var y1 = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                if ((px[y * w + x] ushr 24) > 16) {
                    if (x < x0) x0 = x
                    if (x > x1) x1 = x
                    if (y < y0) y0 = y
                    if (y > y1) y1 = y
                }
            }
        }
        require(x1 >= x0 && y1 >= y0) { "Tokoh tidak terdeteksi. Naikkan toleransi latar atau pakai foto berlatar polos." }
        var chr = Bitmap.createBitmap(seg, x0, y0, x1 - x0 + 1, y1 - y0 + 1)
        if (p.faceLeft) {
            val m = Matrix()
            m.preScale(-1f, 1f)
            chr = Bitmap.createBitmap(chr, 0, 0, chr.width, chr.height, m, true)
        }
        bw = chr.width
        bh = chr.height
        require(bw >= 20 && bh >= 20) { "Tokoh terlalu kecil di dalam foto" }

        val ny = (p.neck * bh).toInt().coerceIn(2, bh - 6)
        val hy = (p.hip * bh).toInt().coerceIn(ny + 3, bh - 2)
        val aw = (p.arm * bw).toInt().coerceIn(2, bw / 2 - 2)
        val ov = max(2, (0.03f * bw).toInt())
        val split = bw / 2

        head = Bitmap.createBitmap(chr, 0, 0, bw, ny)
        torso = Bitmap.createBitmap(chr, aw, ny, bw - 2 * aw, hy - ny)
        val alw = min(bw, aw + ov)
        armLb = Bitmap.createBitmap(chr, 0, ny, alw, hy - ny)
        val arx = max(0, bw - aw - ov)
        armRb = Bitmap.createBitmap(chr, arx, ny, bw - arx, hy - ny)
        val llw = min(bw, split + ov)
        legLb = Bitmap.createBitmap(chr, 0, hy, llw, bh - hy)
        val lrx = max(0, split - ov)
        legRb = Bitmap.createBitmap(chr, lrx, hy, bw - lrx, bh - hy)

        neckY = ny.toFloat()
        hipY = hy.toFloat()
        armW = aw.toFloat()
        armRx = arx.toFloat()
        legRx = lrx.toFloat()
        armPy = ny + 0.03f * bh
        legLpx = split / 2f
        legRpx = split + (bw - split) / 2f
        saluteDeg = Motions.saluteAngle(bw / 2f - aw / 2f, (hy - ny).toFloat())
    }

    private fun part(c: Canvas, b: Bitmap, ox: Float, oy: Float, px: Float, py: Float, ang: Float) {
        c.save()
        c.rotate(ang, px, py)
        c.drawBitmap(b, ox, oy, paint)
        c.restore()
    }

    /** bg == null -> latar transparan. */
    fun render(pose: Pose, cw: Int, ch: Int, bg: Int?): Bitmap {
        val bmp = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (bg != null) c.drawColor(bg)
        val scale = min(ch * 0.70f / bh, cw * 0.62f / bw)
        c.save()
        c.translate(cw / 2f, ch * 0.90f)
        c.scale(scale, scale)
        c.scale(pose.sx, pose.sy)
        c.translate(-bw / 2f, -bh.toFloat())
        c.translate(0f, pose.bob * bh)

        part(c, legRb, legRx, hipY, legRpx, hipY, pose.legR)
        part(c, legLb, 0f, hipY, legLpx, hipY, pose.legL)

        c.save()
        c.rotate(pose.body, bw / 2f, hipY)
        c.drawBitmap(torso, armW, neckY, paint)
        part(c, head, 0f, 0f, bw / 2f, neckY, pose.head)
        part(c, armRb, armRx, neckY, bw - armW / 2f, armPy, pose.armR)
        part(c, armLb, 0f, neckY, armW / 2f, armPy, pose.armL)
        c.restore()

        c.restore()
        return bmp
    }
}
