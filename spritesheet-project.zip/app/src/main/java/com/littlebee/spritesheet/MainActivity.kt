package com.littlebee.spritesheet

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.OutputStream
import kotlin.math.max

class MainActivity : Activity() {

    private val RC_PHOTO = 1
    private val RC_SHEET = 2
    private val RC_MOTION = 3
    private val RC_SAVE = 4

    private val previewBg = 0xFFEFEFEF.toInt()

    private val params = RigParams()
    private val motions = ArrayList<Motion>()
    private var original: Bitmap? = null
    private var seg: Bitmap? = null
    private var segTol = -1
    private var segFaceLeft = false
    private var sheetBmp: Bitmap? = null
    private var source: FrameSource? = null
    private var previewFrames: List<Bitmap> = emptyList()
    private var previewIdx = 0
    private var busy = false
    private var pendingSave: ((OutputStream) -> Unit)? = null
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var etCmd: EditText
    private lateinit var spMotion: Spinner
    private lateinit var etFps: EditText
    private lateinit var spBg: Spinner
    private lateinit var etCols: EditText
    private lateinit var etRows: EditText

    private val bgNames = listOf("Putih", "Hitam", "Hijau (chroma)", "Abu-abu")
    private val bgColors = listOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF00B140.toInt(), 0xFF9E9E9E.toInt())

    private val tick = object : Runnable {
        override fun run() {
            if (previewFrames.isNotEmpty()) {
                previewIdx = (previewIdx + 1) % previewFrames.size
                preview.setImageBitmap(previewFrames[previewIdx])
                handler.postDelayed(this, 1000L / currentFps())
            }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        motions.addAll(Motions.builtIn())

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(40))

        root.addView(label("Sprite Sheet", 26f, true))
        root.addView(label("Satu foto tokoh → sprite sheet → GIF / MP4", 13f, false))

        preview = ImageView(this)
        preview.setBackgroundColor(previewBg)
        preview.scaleType = ImageView.ScaleType.FIT_CENTER
        val plp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(320))
        plp.topMargin = dp(12)
        root.addView(preview, plp)

        status = label("Pilih foto tokoh untuk memulai.", 13f, false)
        root.addView(status)

        // 1. Foto
        root.addView(section("1. Foto tokoh"))
        root.addView(btn("Pilih foto tokoh") { pick(RC_PHOTO, "image/*") })
        val cbLeft = CheckBox(this)
        cbLeft.text = "Tokoh menghadap kiri"
        cbLeft.setOnCheckedChangeListener { _, v -> params.faceLeft = v }
        root.addView(cbLeft)
        root.addView(slider("Posisi leher (% tinggi)", 15, 60, 38) { params.neck = it / 100f })
        root.addView(slider("Posisi pinggul (% tinggi)", 40, 85, 68) { params.hip = it / 100f })
        root.addView(slider("Lebar lengan (% lebar)", 10, 40, 28) { params.arm = it / 100f })
        root.addView(slider("Toleransi latar polos", 5, 90, 40) { params.tol = it })

        // 2. Gerakan
        root.addView(section("2. Perintah gerakan"))
        etCmd = EditText(this)
        etCmd.hint = "ketik: jalan, lari, lompat, salam biksu…"
        etCmd.setSingleLine(true)
        root.addView(etCmd)
        spMotion = Spinner(this)
        refreshMotionSpinner(0)
        spMotion.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                etFps.setText(motions[pos].fps.toString())
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(spMotion)
        etFps = EditText(this)
        etFps.hint = "FPS"
        etFps.inputType = InputType.TYPE_CLASS_NUMBER
        etFps.setText(motions[0].fps.toString())
        root.addView(label("FPS (kecepatan putar)", 12f, false))
        root.addView(etFps)
        root.addView(btn("Impor model gerakan (.json)") { pick(RC_MOTION, "*/*") })
        root.addView(btn("Buat Sprite Sheet") { generate() })

        // 3. Hasil
        root.addView(section("3. Simpan hasil"))
        root.addView(label("Warna latar untuk GIF / MP4", 12f, false))
        spBg = Spinner(this)
        spBg.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, bgNames)
        root.addView(spBg)
        root.addView(btn("Simpan Sprite Sheet (PNG)") { savePng() })
        root.addView(btn("Simpan GIF") { saveGif() })
        root.addView(btn("Simpan MP4") { saveMp4() })

        // 4. Sprite sheet yang sudah ada
        root.addView(section("Sudah punya sprite sheet?"))
        root.addView(label("Pilih PNG sprite sheet, isi jumlah kolom dan baris, lalu langsung buat GIF / MP4.", 12f, false))
        root.addView(btn("Pilih sprite sheet PNG") { pick(RC_SHEET, "image/*") })
        etCols = EditText(this)
        etCols.hint = "Jumlah kolom"
        etCols.inputType = InputType.TYPE_CLASS_NUMBER
        etCols.setText("5")
        etRows = EditText(this)
        etRows.hint = "Jumlah baris"
        etRows.inputType = InputType.TYPE_CLASS_NUMBER
        etRows.setText("4")
        root.addView(etCols)
        root.addView(etRows)
        root.addView(btn("Pakai sprite sheet ini") { useSheet() })

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    /* ---------- helper UI ---------- */

    private fun label(t: String, size: Float, bold: Boolean): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        if (bold) tv.setTypeface(tv.typeface, android.graphics.Typeface.BOLD)
        return tv
    }

    private fun section(t: String): TextView {
        val tv = label(t, 17f, true)
        tv.setPadding(0, dp(20), 0, dp(4))
        return tv
    }

    private fun btn(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun slider(name: String, lo: Int, hi: Int, init: Int, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val tv = TextView(this)
        tv.text = "$name: $init"
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = init - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = "$name: ${p + lo}"
                onChange(p + lo)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    private fun refreshMotionSpinner(sel: Int) {
        spMotion.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, motions.map { it.name }
        )
        spMotion.setSelection(sel)
    }

    private fun setStatus(s: String) {
        runOnUiThread { status.text = s }
    }

    private fun toast(s: String) {
        runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
    }

    private fun currentFps(): Int = etFps.text.toString().toIntOrNull()?.coerceIn(1, 60) ?: 20

    private fun bgColor(): Int = bgColors[spBg.selectedItemPosition.coerceIn(0, bgColors.size - 1)]

    private fun pick(rc: Int, mime: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = mime
        startActivityForResult(i, rc)
    }

    private fun work(msg: String, job: () -> Unit) {
        if (busy) {
            toast("Masih memproses, tunggu sebentar…")
            return
        }
        busy = true
        setStatus(msg)
        Thread {
            try {
                job()
            } catch (e: Throwable) {
                setStatus("Gagal: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                busy = false
            }
        }.start()
    }

    /* ---------- hasil pilih file ---------- */

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            RC_PHOTO -> loadPhoto(uri)
            RC_SHEET -> loadSheet(uri)
            RC_MOTION -> loadMotion(uri)
            RC_SAVE -> runSave(uri)
        }
    }

    private fun decode(uri: Uri, maxSide: Int): Bitmap {
        val o1 = BitmapFactory.Options()
        o1.inJustDecodeBounds = true
        contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o1) }
        var sample = 1
        while (max(o1.outWidth, o1.outHeight) / sample > maxSide) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        o2.inPreferredConfig = Bitmap.Config.ARGB_8888
        return contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: throw IllegalStateException("Gambar tidak bisa dibaca")
    }

    private fun showStatic(b: Bitmap) {
        handler.removeCallbacks(tick)
        previewFrames = emptyList()
        preview.setImageBitmap(b)
    }

    private fun loadPhoto(uri: Uri) {
        work("Membaca foto…") {
            val b = decode(uri, 1024)
            original = b
            seg = null
            runOnUiThread { showStatic(b) }
            setStatus("Foto dimuat (${b.width}×${b.height}). Pilih gerakan lalu tekan Buat Sprite Sheet.")
        }
    }

    private fun loadSheet(uri: Uri) {
        work("Membaca sprite sheet…") {
            val b = decode(uri, 4096)
            sheetBmp = b
            runOnUiThread { showStatic(b) }
            setStatus("Sprite sheet dimuat (${b.width}×${b.height}). Isi kolom dan baris lalu tekan Pakai sprite sheet ini.")
        }
    }

    private fun loadMotion(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
            val m = Motions.fromJson(text)
            motions.add(m)
            refreshMotionSpinner(motions.size - 1)
            setStatus("Model gerakan \"${m.name}\" ditambahkan.")
        } catch (e: Throwable) {
            setStatus("File gerakan tidak valid: ${e.message}")
        }
    }

    /* ---------- buat sprite sheet ---------- */

    private fun pickMotion(): Motion {
        val cmd = etCmd.text.toString().trim().lowercase()
        if (cmd.isNotEmpty()) {
            val m = motions.firstOrNull { mo -> mo.keywords.any { cmd.contains(it) } }
            if (m != null) {
                spMotion.setSelection(motions.indexOf(m))
                return m
            }
        }
        return motions[spMotion.selectedItemPosition.coerceIn(0, motions.size - 1)]
    }

    private fun generate() {
        val photo = original
        if (photo == null) {
            toast("Pilih foto tokoh dulu")
            return
        }
        val motion = pickMotion()
        val tol = params.tol
        val faceLeft = params.faceLeft
        val rp = RigParams(params.neck, params.hip, params.arm, tol, faceLeft)
        work("Memproses foto…") {
            if (seg == null || segTol != tol) {
                setStatus("Membuang latar polos…")
                seg = Segmenter.removeBackground(photo, tol)
                segTol = tol
            }
            setStatus("Membuat kerangka dan ${motion.frameCount} frame…")
            val rig = Rig(seg!!, rp)
            val src = GeneratedSource(rig, motion)
            val frames = ArrayList<Bitmap>()
            for (i in 0 until src.count) frames.add(src.frame(i, SheetBuilder.CW, SheetBuilder.CH, previewBg))
            source = src
            previewFrames = frames
            previewIdx = 0
            runOnUiThread {
                etFps.setText(motion.fps.toString())
                handler.removeCallbacks(tick)
                handler.post(tick)
            }
            setStatus("Siap: ${motion.name}, ${motion.frameCount} frame. Simpan sebagai PNG, GIF, atau MP4.")
        }
    }

    private fun useSheet() {
        val sb = sheetBmp
        if (sb == null) {
            toast("Pilih sprite sheet PNG dulu")
            return
        }
        val cols = etCols.text.toString().toIntOrNull() ?: 0
        val rows = etRows.text.toString().toIntOrNull() ?: 0
        if (cols < 1 || rows < 1 || cols > sb.width || rows > sb.height) {
            toast("Jumlah kolom dan baris tidak valid")
            return
        }
        work("Menyiapkan sprite sheet…") {
            val src = SheetSource(sb, cols, rows)
            val (pw, ph) = fitSize(src.natW, src.natH, 320, 1)
            val frames = ArrayList<Bitmap>()
            for (i in 0 until src.count) frames.add(src.frame(i, pw, ph, previewBg))
            source = src
            previewFrames = frames
            previewIdx = 0
            runOnUiThread {
                handler.removeCallbacks(tick)
                handler.post(tick)
            }
            setStatus("Sprite sheet dipakai: ${src.count} frame. Tinggal simpan GIF atau MP4.")
        }
    }

    /* ---------- simpan ---------- */

    private fun ask(name: String, mime: String, job: (OutputStream) -> Unit) {
        pendingSave = job
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = mime
        i.putExtra(Intent.EXTRA_TITLE, name)
        startActivityForResult(i, RC_SAVE)
    }

    private fun runSave(uri: Uri) {
        val job = pendingSave ?: return
        pendingSave = null
        work("Menyimpan…") {
            contentResolver.openOutputStream(uri)!!.use { os -> job(os) }
            setStatus("Tersimpan. Cek di lokasi yang kamu pilih.")
            toast("Tersimpan")
        }
    }

    private fun savePng() {
        val s = source
        if (s is GeneratedSource) {
            ask("spritesheet.png", "image/png") { os ->
                setStatus("Menyusun sprite sheet…")
                val sheet = SheetBuilder.build(s)
                sheet.compress(Bitmap.CompressFormat.PNG, 100, os)
            }
        } else if (s is SheetSource) {
            toast("Sprite sheet ini sudah berupa file PNG milik kamu")
        } else {
            toast("Buat sprite sheet dari foto dulu")
        }
    }

    private fun saveGif() {
        val s = source
        if (s == null) {
            toast("Buat atau pilih sprite sheet dulu")
            return
        }
        val fps = currentFps()
        val bg = bgColor()
        val size = if (s is GeneratedSource) Pair(SheetBuilder.CW, SheetBuilder.CH) else fitSize(s.natW, s.natH, 480, 1)
        ask("sprite.gif", "image/gif") { os ->
            GifExporter.export(s, size.first, size.second, fps, bg, os) { setStatus(it) }
        }
    }

    private fun saveMp4() {
        val s = source
        if (s == null) {
            toast("Buat atau pilih sprite sheet dulu")
            return
        }
        val fps = currentFps()
        val bg = bgColor()
        val size = if (s is GeneratedSource) Pair(512, 640) else fitSize(s.natW, s.natH, 720, 16)
        ask("sprite.mp4", "video/mp4") { os ->
            val tmp = File(cacheDir, "tmp_sprite.mp4")
            if (tmp.exists()) tmp.delete()
            Mp4Exporter.export(s, size.first, size.second, fps, bg, tmp) { setStatus(it) }
            tmp.inputStream().use { it.copyTo(os) }
            tmp.delete()
        }
    }
}
