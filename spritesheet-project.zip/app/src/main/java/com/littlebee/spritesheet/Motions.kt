package com.littlebee.spritesheet

import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.sin

/** Satu pose tubuh. Sudut dalam derajat (positif = searah jarum jam), bob/ukuran dalam pecahan tinggi tokoh. */
data class Pose(
    val bob: Float = 0f,
    val body: Float = 0f,
    val head: Float = 0f,
    val armL: Float = 0f,
    val armR: Float = 0f,
    val legL: Float = 0f,
    val legR: Float = 0f,
    val sx: Float = 1f,
    val sy: Float = 1f
)

/** Satu klip gerakan. gen(indexFrame, sudutSalam) -> Pose. */
class Motion(
    val name: String,
    val keywords: List<String>,
    val frameCount: Int,
    val fps: Int,
    val gen: (Int, Float) -> Pose
)

private const val TAU = 6.2831853f

fun smooth(a: Float, b: Float, x: Float): Float {
    val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

fun lerpPose(a: Pose, b: Pose, t: Float): Pose = Pose(
    lerp(a.bob, b.bob, t), lerp(a.body, b.body, t), lerp(a.head, b.head, t),
    lerp(a.armL, b.armL, t), lerp(a.armR, b.armR, t),
    lerp(a.legL, b.legL, t), lerp(a.legR, b.legR, t),
    lerp(a.sx, b.sx, t), lerp(a.sy, b.sy, t)
)

/** Siklus jalan. ph = fase 0..1 (periodik), k = skala amplitudo. */
fun walkPose(ph: Float, k: Float = 1f): Pose {
    val s = sin(ph * TAU)
    val leg = 28f * s
    return Pose(
        bob = -0.012f * abs(s) * k,
        body = 3f * k,
        head = -1.5f * k,
        armL = -0.8f * leg * k,
        armR = 0.8f * leg * k,
        legL = leg * k,
        legR = -leg * k
    )
}

fun runPose(ph: Float): Pose {
    val s = sin(ph * TAU)
    val leg = 46f * s
    return Pose(
        bob = -0.03f * abs(s),
        body = 9f,
        head = -4f,
        armL = -1.2f * leg,
        armR = 1.2f * leg,
        legL = leg,
        legR = -leg
    )
}

fun jumpPose(t: Float): Pose {
    val up = smooth(0.15f, 0.5f, t) - smooth(0.5f, 0.85f, t)
    val squat = smooth(0f, 0.15f, t) - smooth(0.15f, 0.3f, t) +
        smooth(0.85f, 0.92f, t) - smooth(0.92f, 1f, t)
    return Pose(
        bob = -0.25f * up + 0.04f * squat,
        sx = 1f + 0.05f * squat - 0.03f * up,
        sy = 1f - 0.08f * squat + 0.05f * up,
        armL = 50f * up,
        armR = -50f * up,
        legL = 15f * up,
        legR = -15f * up
    )
}

fun idlePose(t: Float): Pose {
    val s = sin(t * TAU)
    return Pose(
        sy = 1f + 0.012f * s,
        armL = 3f * s,
        armR = -3f * s,
        head = 1.2f * sin(t * TAU + 1f)
    )
}

fun wavePose(t: Float): Pose {
    val raise = smooth(0f, 0.2f, t) - smooth(0.8f, 1f, t)
    val wiggle = sin(t * TAU * 3f) * 18f * raise
    return Pose(
        armR = -(135f * raise + wiggle),
        head = 4f * raise
    )
}

/** Salam hormat: kedua tangan menyatu di depan dada/perut, menunduk, lalu kembali tegak. */
fun salutePose(t: Float, saluteDeg: Float, sx: Float): Pose {
    val a = smooth(0f, 0.30f, t) - smooth(0.85f, 1f, t)
    val bow = smooth(0.45f, 0.62f, t) - smooth(0.72f, 0.9f, t)
    return Pose(
        bob = 0.01f * bow,
        body = 20f * bow,
        head = 12f * bow,
        armL = -saluteDeg * a,
        armR = saluteDeg * a,
        sx = sx
    )
}

/** Berputar dari samping ke depan (efek boneka kertas): badan menyempit, ayunan jalan mereda. */
fun turnPose(t: Float): Pose {
    val s = smooth(0f, 1f, t)
    val w = walkPose(1f + 0.5f * t, 1f - s)
    return w.copy(sx = 1f - 0.28f * s)
}

object Motions {
    fun builtIn(): List<Motion> = listOf(
        Motion("Salam Biksu (jalan, putar, salam)", listOf("biksu", "putar", "menghadap", "jalan lalu"), 60, 20) { i, sd ->
            when {
                i < 20 -> walkPose(i / 20f)
                i < 40 -> turnPose((i - 20) / 20f)
                else -> salutePose((i - 40) / 20f, sd, 0.72f)
            }
        },
        Motion("Salam hormat", listOf("salam", "hormat", "sembah"), 20, 20) { i, sd ->
            salutePose(i / 20f, sd, 1f)
        },
        Motion("Lari", listOf("lari", "run", "sprint"), 20, 30) { i, _ -> runPose(i / 20f) },
        Motion("Lompat", listOf("lompat", "loncat", "jump"), 20, 20) { i, _ -> jumpPose(i / 20f) },
        Motion("Lambai tangan", listOf("lambai", "wave", "halo"), 20, 20) { i, _ -> wavePose(i / 20f) },
        Motion("Diam (napas)", listOf("diam", "napas", "idle"), 20, 12) { i, _ -> idlePose(i / 20f) },
        Motion("Jalan", listOf("jalan", "walk", "melangkah"), 20, 20) { i, _ -> walkPose(i / 20f) }
    )

    /**
     * Format JSON model gerakan:
     * {"name":"gerakan saya","fps":20,"frames":[{"legL":10,"legR":-10,"armL":-8,"armR":8,"body":3,"head":0,"bob":0,"sx":1,"sy":1}, ...]}
     * Jumlah frame bebas (minimal 2), otomatis dibagi rata menjadi 20 frame.
     */
    fun fromJson(text: String): Motion {
        val o = JSONObject(text)
        val name = o.optString("name", "Gerakan kustom")
        val fps = o.optInt("fps", 20).coerceIn(1, 60)
        val arr = o.getJSONArray("frames")
        val poses = ArrayList<Pose>()
        for (k in 0 until arr.length()) {
            val f = arr.getJSONObject(k)
            poses.add(
                Pose(
                    bob = f.optDouble("bob", 0.0).toFloat(),
                    body = f.optDouble("body", 0.0).toFloat(),
                    head = f.optDouble("head", 0.0).toFloat(),
                    armL = f.optDouble("armL", 0.0).toFloat(),
                    armR = f.optDouble("armR", 0.0).toFloat(),
                    legL = f.optDouble("legL", 0.0).toFloat(),
                    legR = f.optDouble("legR", 0.0).toFloat(),
                    sx = f.optDouble("sx", 1.0).toFloat(),
                    sy = f.optDouble("sy", 1.0).toFloat()
                )
            )
        }
        require(poses.size >= 2) { "Minimal 2 frame pada file gerakan" }
        val n = 20
        return Motion(name, listOf(name.lowercase()), n, fps) { i, _ ->
            val pos = i * (poses.size - 1) / (n - 1).toFloat()
            val a = pos.toInt().coerceAtMost(poses.size - 2)
            lerpPose(poses[a], poses[a + 1], pos - a)
        }
    }

    fun saluteAngle(armCenterDx: Float, armLen: Float): Float {
        val r = (armCenterDx / armLen).coerceIn(0f, 0.95f)
        return Math.toDegrees(asin(r).toDouble()).toFloat().coerceIn(25f, 80f)
    }
}
