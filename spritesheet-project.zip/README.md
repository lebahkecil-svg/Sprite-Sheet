# Sprite Sheet (Android native, Kotlin)

Unggah 1 foto tokoh -> pilih gerakan -> sprite sheet 20 frame -> simpan PNG / GIF / MP4.

## Cara pakai
1. Pilih foto tokoh (badan penuh, latar polos). Atur slider leher, pinggul, lebar lengan, toleransi latar bila perlu.
2. Ketik perintah (jalan, lari, lompat, lambai, diam, salam, salam biksu) atau pilih dari daftar.
3. Tekan Buat Sprite Sheet, lihat pratinjau, lalu simpan PNG / GIF / MP4.
4. Sudah punya sprite sheet? Pilih PNG-nya, isi kolom dan baris, tekan Pakai sprite sheet ini.
5. Impor model gerakan (.json): lihat contoh_gerakan.json. Sudut dalam derajat (positif = searah jarum jam).

## Build
Push zip ini ke GitHub (nama file: spritesheet-project.zip) bersama .github/workflows/build.yml,
jalankan workflow Build APK, unduh artifact SpriteSheet-APK.

## Catatan
- Piksel tokoh diambil langsung dari foto (dipotong jadi kepala, badan, lengan, kaki), tidak digambar ulang.
- Dengan 1 foto, putaran samping -> depan berupa efek boneka kertas.
